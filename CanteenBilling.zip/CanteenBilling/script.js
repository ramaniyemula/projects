// Function to calculate the total bill
function calculateBill() {
    const foodItems = document.querySelectorAll('.food-item');
    let total = 0;
    let billDetails = "Selected Items:<br>";

    foodItems.forEach(item => {
        const price = parseInt(item.querySelector('span').textContent.split('₹')[1]);
        const quantity = parseInt(item.querySelector('.quantity').value);

        if (quantity > 0) {
            total += price * quantity;
            billDetails += `${item.querySelector('span').textContent} - ${quantity} x ₹${price} = ₹${price * quantity}<br>`;
        }
    });

    billDetails += `<strong>Total Bill: ₹${total}</strong>`;
    document.getElementById('billDetails').innerHTML = billDetails;
}

// Function to add a new item
function addNewItem() {
    const itemName = document.getElementById('newItemName').value;
    const itemPrice = document.getElementById('newItemPrice').value;

    if (itemName && itemPrice) {
        const foodItems = document.getElementById('foodItems');
        const div = document.createElement('div');
        div.className = 'food-item';
        div.innerHTML = `
            <span>${itemName} - ₹${itemPrice}</span>
            <div class="quantity-controls">
                <button class="minus-btn">-</button>
                <input type="number" class="quantity" value="0" min="0">
                <button class="plus-btn">+</button>
            </div>
        `;
        foodItems.appendChild(div);

        // Clear input fields
        document.getElementById('newItemName').value = '';
        document.getElementById('newItemPrice').value = '';

        // Add event listeners for + and - buttons
        div.querySelector('.plus-btn').addEventListener('click', () => {
            const input = div.querySelector('.quantity');
            input.value = parseInt(input.value) + 1;
        });

        div.querySelector('.minus-btn').addEventListener('click', () => {
            const input = div.querySelector('.quantity');
            if (input.value > 0) {
                input.value = parseInt(input.value) - 1;
            }
        });
    } else {
        alert('Please enter both item name and price.');
    }
}

// Add event listeners for + and - buttons
document.querySelectorAll('.plus-btn').forEach(button => {
    button.addEventListener('click', () => {
        const input = button.parentElement.querySelector('.quantity');
        input.value = parseInt(input.value) + 1;
    });
});

document.querySelectorAll('.minus-btn').forEach(button => {
    button.addEventListener('click', () => {
        const input = button.parentElement.querySelector('.quantity');
        if (input.value > 0) {
            input.value = parseInt(input.value) - 1;
        }
    });
});